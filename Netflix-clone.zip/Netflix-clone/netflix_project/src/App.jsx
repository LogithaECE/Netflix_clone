
import './App.css'

function App() {
  return (
    <>
  <div class="outter-container">
  
  <header class="header">
    <nav class="logo">
      <img src="https://i.ibb.co/r5krrdz/logo.png" alt="Netflix" /><div className="btnGrp">
      <a href="/login/register" style={{textDecorationColor:"white"}} className="btn"><button style={{backgroundColor:"red"}}>Sign up </button></a>
      <a href="/login" style={{textDecorationColor:"white"}} className="btn"><button style={{backgroundColor:"red"}}>Login </button></a></div>
    </nav>

    <div class="inner-container">
      <div class="inner-title">
        <h1>Watch unlimited movies, TV shows, and more.</h1>
      </div>
      <div class="inner-text">
        <p>Watch anywhere anytime.</p>
      </div>

      <div class="email-form">
        <p>
          Ready to watch? 
        </p>

        <div class="get-started">

        <a href="/login/homepage" className="startLink"><button style={{backgroundColor:"red"}}  className="btn">Get started </button></a>
        </div>
      </div>
    </div>
    <div class="overlay"></div>
  </header>
</div>

    </>
  )
}

export default App
