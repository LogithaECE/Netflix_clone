import React, { useState } from 'react';
import './login.css';

const Register = () => {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const handleRegister = async () => {
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, password })
      });

      const data = await response.json();

      if (response.ok) {
        alert('Registration successful!');
        window.location.href = '/homepage/movieDetail';
      } else {
        setError(data.message || 'Registration failed. Please try again.');
      }
    } catch (error) {
      console.error('Error registering user:', error);
      setError('Something went wrong. Please try again.');
    }
  };

  return (
    <body className='register_body'>
      <header>
        <img src="https://i.ibb.co/r5krrdz/logo.png" alt="Netflix Logo" />
      </header>
      <div className="sigreg" style={{ display: "inline-block", width: "auto" }}>
        <h2>Watch anywhere, Cancel anytime</h2><br></br>
        <input
          type="text"
          placeholder="Email Address"
          value={name}
          onChange={(e) => setName(e.target.value)}
         
        />
        <br />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        
        />
        <br />
        <input
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
         
        />
        <br />
        <button
          style={{ backgroundColor: 'red', marginLeft: '40px' }}
          onClick={handleRegister}
        >
          Register
        </button>
        <br />
        {error && <p style={{ color: 'red',margin:"0px 85px", fontWeight: "lighter", fontSize:"smaller"}}>{error}</p>}
      </div>
      <div class="show">
        <div class="showcase-img">
          <img
            src="https://assets.nflxext.com/ffe/siteui/acquisition/ourStory/fuji/desktop/device-pile.png"
            alt=""
          />
        </div>
        <video className="showcase-animation" autoPlay playsInline muted loop>
          <source
            src="https://assets.nflxext.com/ffe/siteui/acquisition/ourStory/fuji/desktop/video-devices.m4v"
            type="video/mp4"
          />
        </video>
      </div>
    </body>
  );
};

export default Register;
