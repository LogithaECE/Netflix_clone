import React, { useState } from 'react';
import './login.css';

const Login = () => {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const validateUser = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/validateUser', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, password })
      });

      const data = await response.json();

      if (response.ok) {
        alert('Logged in successfully!');
        console.log('User validated successfully');
        window.location.href = '/homepage/movieDetail';
      } else {
        console.error('Error validating user:', data.message);
        setError(data.message);
      }
    } catch (error) {
      console.error('Error validating user:', error);
      setError('Something went wrong. Please try again.');
    }
  };

  return (
    <div>
      <header>
        <img src="https://i.ibb.co/r5krrdz/logo.png" alt="Netflix Logo" />
      </header>
      <div className="sig">
        <h1>Sign In</h1>
        <input
          type="text"
          placeholder="Email Address"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <br />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <br />
        <button
          style={{ backgroundColor: 'red', marginLeft: '40px' }}
          onClick={validateUser}
        >
          Login
        </button>
        <br />
        {error && <p style={{ color: 'red', fontSize:"small", marginLeft:"90px"}}>{error}</p>}
        <a href="/login/register" style={{ color: 'grey', marginLeft: '80px' }}>
          <u>New To Netflix? Create an account</u>
        </a>
      </div>
    </div>
  );
};

export default Login;
