
const express = require('express');
const mongoose = require('mongoose');
const app = express();
const port = 3000;
const cors = require('cors');
app.use(cors());


mongoose.connect('mongodb://127.0.0.1:27017/netflix_users');

const UserSchema = new mongoose.Schema({
  name: String,
  password: String
});

const User = mongoose.model('User', UserSchema);
app.use(express.json());
app.use(express.static('public'));

app.post('/api/validateUser', async (req, res) => {
  const { name, password } = req.body;

  try {
    
    const user = await User.findOne({ name, password });

    if (user) {
      res.json({ success: true, message: 'User validated successfully' });
    } else {
      res.status(400).json({ success: false, message: 'Invalid username or password' });
    }
  } catch (error) {
   
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

app.post('/api/register', async (req, res) => {
  const { name, password } = req.body;

  try {
   
    const existingUser = await User.findOne({ name });
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'Email already registered' });
    }
    else if(name==""||password==""){
      return res.status(400).json({ success: false, message: 'All fields are necessary' });
    }
    else if(!name.includes("@gmail.com")){
      return res.status(400).json({ success: false, message: ' Enter valid EmailID' });
    }
    else if(password.length <8){
      return res.status(400).json({ success: false, message: 'Password has atleast 8 characters' });
    }

    const newUser = new User({ name, password });
    await newUser.save();

    res.status(201).json({ success: true, message: 'User registered successfully' });
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
